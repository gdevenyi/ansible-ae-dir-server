# -*- coding: utf-8 -*-
"""
Package for various plugin modules
"""
