# -*- coding: utf-8 -*-
"""
web2ldap plugin classes for OpenSSH-LPK
(see https://code.google.com/p/openssh-lpk/)
"""

import re,hashlib


from w2lapp.schema.syntaxes import DirectoryString,syntax_registry

class SshPublicKey(DirectoryString):
  oid = 'SshPublicKey-oid'
  desc = 'SSH public key of a user'
  reObj = re.compile('(^|.* )(ssh-rsa|ssh-dss|ecdsa-sha2-nistp256|ssh-ed25519) (?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)? .+$')
  # names of hash algorithms to be used when displaying fingerprint(s)
  hash_algorithms = ('md5','sha1','sha256')
  fileExt = 'pub'

  def sanitizeInput(self,attrValue):
    if attrValue!=None:
      return DirectoryString.sanitizeInput(self,attrValue).strip().replace('\r','').replace('\n','')
    else:
      return attrValue

  def _extract_pk_params(self):
    attr_value = self.attrValue.decode(self._ls.charset)
    try:
      pk_type,pk_base64,pk_comment = attr_value.split(' ',2)
    except ValueError:
      pk_comment = None
      pk_type,pk_base64 = attr_value.split(' ',1)
    try:
      pk_bin = pk_base64.decode('base64')
      pk_fingerprints = dict([
        (hash_algo,':'.join([b.encode('hex') for b in hashlib.new(hash_algo,pk_bin).digest()]))
        for hash_algo in self.hash_algorithms
      ])
      pk_len = len(pk_bin)
    except:
      pk_bin,pk_fingerprints = None,None
    return pk_type,pk_comment,pk_bin,pk_fingerprints

  def _display_lines(self,valueindex,commandbutton,pk_type,pk_comment,pk_bin,pk_fingerprints):
    result = []
    result.append('<dt>SSH Key:</dt><dd><input readonly size="70" value="{}"></dd>'.format(
      DirectoryString.displayValue(self,valueindex,commandbutton)
    ))
    if pk_comment:
      result.append('<dt>Key comment:</dt><dd>{}</dd>'.format(self._form.utf2display(pk_comment)))
    if pk_fingerprints:
      result.append('<dt>Fingerprints:</dt><dd><dl>')
      for hash_algo,pk_fingerprint in pk_fingerprints.items():
        result.append('<dt>{0}:</dt><dd>{1}</dd>'.format(hash_algo.upper(),pk_fingerprint))
      result.append('</dl></dd>')
    return result

  def displayValue(self,valueindex=0,commandbutton=0):
    pk_type,pk_comment,pk_bin,pk_fingerprints = self._extract_pk_params()
    result = ['<dl>']
    result.extend(self._display_lines(valueindex,commandbutton,pk_type,pk_comment,pk_bin,pk_fingerprints))
    result.append('</dl>')
    return '\n'.join(result)

try:

  import paramiko

except ImportError:

  syntax_registry.registerAttrType(
    SshPublicKey.oid,[
      '1.3.6.1.4.1.24552.500.1.1.1.13', # sshPublicKey
    ]
  )

else:

  PARAMIKO_KEYCLASS = {
    'ssh-rsa':paramiko.RSAKey,
    'ssh-dss':paramiko.DSSKey,
  }

  class ParamikoSshPublicKey(SshPublicKey):
    oid = 'ParamikoSshPublicKey-oid'

    def _display_lines(self,valueindex,commandbutton,pk_type,pk_comment,pk_bin,pk_fingerprints):
      result = SshPublicKey._display_lines(self,valueindex,commandbutton,pk_type,pk_comment,pk_bin,pk_fingerprints)
      if pk_bin:
        try:
          p = PARAMIKO_KEYCLASS[pk_type](data=pk_bin)
        except KeyError:
          pass
        except paramiko.SSHException,e:
          result.append('<p class="ErrorMessage">SSHException: %s</p>' % (
            self._form.utf2display(unicode(e)),
          ))
        else:
          pk_size = p.get_bits()
          result.append('<dt>Key size:</dt><dd>%d</dd>' % (pk_size))
      return result

  syntax_registry.registerAttrType(
    ParamikoSshPublicKey.oid,[
      '1.3.6.1.4.1.24552.500.1.1.1.13', # sshPublicKey
    ]
  )


# Register all syntax classes in this module
for symbol_name in dir():
  syntax_registry.registerSyntaxClass(eval(symbol_name))
